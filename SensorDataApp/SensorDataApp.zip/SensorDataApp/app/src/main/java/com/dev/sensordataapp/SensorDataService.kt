package com.dev.sensordataapp

import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.widget.Toast
import android.R.attr.start
import android.hardware.SensorManager
import android.os.*
import android.util.Log
import android.widget.Chronometer
import androidx.annotation.RequiresApi
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class SensorDataService : Service(),SensorEventListener {
    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
        Log.e("sensor changed",p0?.name+" : "+p1)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onSensorChanged(p0: SensorEvent?) {
        Log.e("sensor changed",p0?.sensor?.name+" - values : "+ p0?.values?.get(0))
        val jsonObject = JSONObject()
        jsonObject.put("SensorName",p0?.sensor?.name)
        when(p0?.sensor?.name) {
           "LIGHT" -> {
               jsonObject.put("SI lux",p0?.values?.get(0))
           }
           "PRESSURE" -> {
                jsonObject.put("atmosphere",p0?.values?.get(0))
            }
            "PROXIMITY" -> {
                jsonObject.put("distance",p0?.values?.get(0))
            }
            "ROTATION_VECTOR" -> {
                jsonObject.put("X*sin(θ/2)",p0?.values?.get(0))
                jsonObject.put("Y*sin(θ/2)",p0?.values?.get(1))
                jsonObject.put("Z*sin(θ/2)",p0?.values?.get(2))
                jsonObject.put("cos(θ/2)",p0?.values?.get(3))
                jsonObject.put("headingAccuracy",p0?.values?.get(4))

            }
            "RELATIVE_HUMIDITY" -> {
                jsonObject.put("humidity",p0?.values?.get(0))
            }
            "AMBIENT_TEMPERATURE"-> {
                jsonObject.put("temperature",p0?.values?.get(0))
            }
            "MAGNETIC_FIELD_UNCALIBRATED" -> {
                jsonObject.put("X_uncalib",p0?.values?.get(0))
                jsonObject.put("Y_uncalib",p0?.values?.get(1))
                jsonObject.put("Z_uncalib)",p0?.values?.get(2))
                jsonObject.put("X_bias",p0?.values?.get(3))
                jsonObject.put("Y_bias",p0?.values?.get(4))
                jsonObject.put("Z_bias",p0?.values?.get(5))
            }
            "GAME_ROTATION_VECTOR" ->{
                jsonObject.put("X*sin(θ/2)",p0?.values?.get(0))
                jsonObject.put("Y*sin(θ/2)",p0?.values?.get(1))
                jsonObject.put("Z*sin(θ/2)",p0?.values?.get(2))
                jsonObject.put("cos(θ/2)",p0?.values?.get(3))
                jsonObject.put("headingAccuracy",p0?.values?.get(4))
            }
            "GYROSCOPE_UNCALIBRATED" ->  {
                jsonObject.put("angular_speed_X",p0?.values?.get(0))
                jsonObject.put("angular_speed_Y",p0?.values?.get(1))
                jsonObject.put("angular_speed_Z)",p0?.values?.get(2))
                jsonObject.put("estimated_drift_X",p0?.values?.get(3))
                jsonObject.put("estimated_drift_Y",p0?.values?.get(4))
                jsonObject.put("estimated_drift_Z",p0?.values?.get(5))
            }
            "POSE_6DOF" -> {
                jsonObject.put("X*sin(θ/2)",p0?.values?.get(0))
                jsonObject.put("Y*sin(θ/2)",p0?.values?.get(1))
                jsonObject.put("Z*sin(θ/2)",p0?.values?.get(2))
                jsonObject.put("cos(θ/2)",p0?.values?.get(3))
                jsonObject.put("translation_along_x",p0?.values?.get(4))
                jsonObject.put("translation_along_y",p0?.values?.get(5))
                jsonObject.put("translation_along_z",p0?.values?.get(6))
                jsonObject.put("Delta_quaternion_rotation_x*sin(θ/2))",p0?.values?.get(7))
                jsonObject.put("Delta_quaternion_rotation_y*sin(θ/2))",p0?.values?.get(8))
                jsonObject.put("Delta_quaternion_rotation_z*sin(θ/2))",p0?.values?.get(9))
                jsonObject.put("Delta_quaternion_rotation_cos(θ/2))",p0?.values?.get(10))
                jsonObject.put("Delta_translation_along_x",p0?.values?.get(11))
                jsonObject.put("Delta_translation_along_y",p0?.values?.get(12))
                jsonObject.put("Delta_translation_along_z",p0?.values?.get(13))
                jsonObject.put("sequence_number",p0?.values?.get(14))
            }
            "STATIONARY_DETECT"-> {
                jsonObject.put("stationary",p0?.values?.get(0))
            }
            "MOTION_DETECT"-> {
                jsonObject.put("in_motion",p0?.values?.get(0))
            }
            "HEART_BEAT"-> {
                jsonObject.put("confidence",p0?.values?.get(0))
            }
            "LOW_LATENCY_OFFBODY_DETECT"-> {
                jsonObject.put("offbody_state",p0?.values?.get(0))
            }
            "ACCELEROMETER_UNCALIBRATED"-> {
                jsonObject.put("X_uncalib",p0?.values?.get(0))
                jsonObject.put("Y_uncalib",p0?.values?.get(1))
                jsonObject.put("Z_uncalib)",p0?.values?.get(2))
                jsonObject.put("X_bias",p0?.values?.get(3))
                jsonObject.put("Y_bias",p0?.values?.get(4))
                jsonObject.put("Z_bias",p0?.values?.get(5))
            }
            else  -> {
                jsonObject.put("X",p0?.values?.get(0))
                jsonObject.put("Y",p0?.values?.get(1))
                jsonObject.put("Z",p0?.values?.get(2))
            }

        }
        val current = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
        val formatted = current.format(formatter)
        jsonObject.put("dateTime",formatted)
        results.put(jsonObject)
    }

    private val LOG_TAG = "BoundService"
    private val mBinder = MyBinder()
    private var mChronometer: Chronometer? = null
    private lateinit var handler : Handler
    lateinit var sensors : List<Sensor>
    lateinit var sensorManager : SensorManager
    var results = JSONArray()
    override fun onCreate() {
        super.onCreate()
        Log.v(LOG_TAG, "in onCreate")
        mChronometer = Chronometer(this)
        mChronometer!!.base = SystemClock.elapsedRealtime()
        mChronometer!!.start()

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager



        handler = Handler()
        handler.postDelayed(Runnable {
            Toast.makeText(this,"oooooooooh",Toast.LENGTH_LONG).show()
            val intent = Intent("stopservice")

            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        },60000)

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        Log.v(LOG_TAG, "in onBind")
        sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)

        sensors.forEach {
            Log.e("sensor",it.toString())

            sensorManager.registerListener(this,it,SensorManager.SENSOR_DELAY_NORMAL)
        }
        return mBinder
    }

    override fun onRebind(intent: Intent) {
        Log.v(LOG_TAG, "in onRebind")
        super.onRebind(intent)
    }

    override fun onUnbind(intent: Intent): Boolean {
        Log.v(LOG_TAG, "in onUnbind")
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.v(LOG_TAG, "in onDestroy")
        mChronometer!!.stop()
    }

    fun schedule() {

    }

    fun sendData() {

    }
    fun getTimestamp(): String {
        val elapsedMillis = SystemClock.elapsedRealtime() - mChronometer!!.base
        val hours = (elapsedMillis / 3600000).toInt()
        val minutes = (elapsedMillis - hours * 3600000).toInt() / 60000
        val seconds =
            (elapsedMillis - (hours * 3600000).toLong() - (minutes * 60000).toLong()).toInt() / 1000
        val millis =
            (elapsedMillis - (hours * 3600000).toLong() - (minutes * 60000).toLong() - (seconds * 1000).toLong()).toInt()
        return "$hours:$minutes:$seconds:$millis"
    }

    inner class MyBinder : Binder() {
        //Return object of BoundService class which can be used to access all the public methods of this class
        internal val service: SensorDataService
            get() = this@SensorDataService
    }
}