package com.dev.sensordataapp

import java.util.*

class SensorData {

     var phoneModel =""
     var androidVersion =""
     var data = ""

}