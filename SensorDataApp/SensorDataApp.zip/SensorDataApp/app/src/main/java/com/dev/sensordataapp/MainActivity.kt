package com.dev.sensordataapp

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import com.dev.sensordataapp.SensorDataService.MyBinder
import android.os.IBinder
import android.content.Context.BIND_AUTO_CREATE
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.content.Intent
import android.content.BroadcastReceiver
import androidx.localbroadcastmanager.content.LocalBroadcastManager


class MainActivity : AppCompatActivity() {
    lateinit var mSensorDataService: SensorDataService
    var mServiceBound = false
    lateinit var mMessageReceiver: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mMessageReceiver = object:BroadcastReceiver() {
            override fun onReceive(p0: Context?, p1: Intent?) {
                /*unbindService(mServiceConnection)
                Log.e("mainact","stopping service")
                mServiceBound = false*/
            }

        }

        val timestampText = findViewById(R.id.timestamp_text) as TextView
        val stopServiceButon = findViewById(R.id.stop_service) as Button
        print_timestamp.setOnClickListener {
            if (mServiceBound) {
                timestampText.setText(mSensorDataService.getTimestamp())
            }
        }
        bind.setOnClickListener {
            val intent = Intent(applicationContext, SensorDataService::class.java)
            //Service starts automatically when binded
            //startService(intent);
            bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE)
        }

        stop_service.setOnClickListener {
            if (mServiceBound) {
                unbindService(mServiceConnection)
                mServiceBound = false
            }

        }
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
        if (mServiceBound) {
            unbindService(mServiceConnection)
            mServiceBound = false
        }
    }

    private val mServiceConnection = object : ServiceConnection {
        override fun onServiceDisconnected(name: ComponentName) {
            mServiceBound = false
        }

        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            val myBinder = service as SensorDataService.MyBinder
            mSensorDataService = myBinder.service
            mServiceBound = true
            LocalBroadcastManager.getInstance(applicationContext).registerReceiver(mMessageReceiver,IntentFilter("stopservice"))
        }
    }

}
